<?php
// ============================================================
// crud.php — Operaciones CRUD del Sistema de Pedidos
// Requiere: conexion.php
// ============================================================

require_once 'conexion.php';

// ============================================================
// CRUD — PRODUCTOS
// ============================================================

/** Listar todos los productos */
function obtenerProductos() {
    $conn = getConexion();
    $res  = $conn->query("SELECT id, nombre, precio FROM productos ORDER BY nombre ASC");
    $data = [];
    while ($row = $res->fetch_assoc()) {
        $row['precio'] = (float)$row['precio'];
        $data[] = $row;
    }
    $conn->close();
    return $data;
}

/** Obtener un producto por ID */
function obtenerProductoPorId($id) {
    $conn = getConexion();
    $id   = (int)$id;
    $res  = $conn->query("SELECT id, nombre, precio FROM productos WHERE id = $id");
    $row  = $res->num_rows > 0 ? $res->fetch_assoc() : null;
    if ($row) $row['precio'] = (float)$row['precio'];
    $conn->close();
    return $row;
}

// ============================================================
// CRUD — CLIENTES
// ============================================================

/** Listar todos los clientes ordenados por Apellido, Nombre */
function obtenerClientes() {
    $conn = getConexion();
    $res  = $conn->query(
        "SELECT id, cedula, nombre, apellido, telefono, email, creado_en
         FROM clientes
         ORDER BY apellido ASC, nombre ASC"
    );
    $data = [];
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }
    $conn->close();
    return $data;
}

/** Buscar cliente por cédula */
function obtenerClientePorCedula($cedula) {
    $conn   = getConexion();
    $cedula = $conn->real_escape_string(trim($cedula));
    $res    = $conn->query(
        "SELECT id, cedula, nombre, apellido, telefono, email, creado_en
         FROM clientes WHERE cedula = '$cedula'"
    );
    $row = $res->num_rows > 0 ? $res->fetch_assoc() : null;
    $conn->close();
    return $row;
}

/** Obtener cliente por ID */
function obtenerClientePorId($id) {
    $conn = getConexion();
    $id   = (int)$id;
    $res  = $conn->query(
        "SELECT id, cedula, nombre, apellido, telefono, email
         FROM clientes WHERE id = $id"
    );
    $row = $res->num_rows > 0 ? $res->fetch_assoc() : null;
    $conn->close();
    return $row;
}

// ============================================================
// CRUD — PEDIDOS
// ============================================================

/** Listar todos los pedidos con detalle de cliente y producto */
function obtenerPedidos() {
    $conn = getConexion();
    $res  = $conn->query(
        "SELECT p.id, p.cantidad, p.total, p.fecha,
                c.nombre AS cliente_nombre, c.apellido AS cliente_apellido, c.cedula,
                pr.nombre AS producto_nombre
         FROM pedidos p
         INNER JOIN clientes  c  ON p.cliente_id  = c.id
         INNER JOIN productos pr ON p.producto_id = pr.id
         ORDER BY p.fecha DESC"
    );
    $data = [];
    while ($row = $res->fetch_assoc()) {
        $row['total']    = (float)$row['total'];
        $row['cantidad'] = (int)$row['cantidad'];
        $data[] = $row;
    }
    $conn->close();
    return $data;
}

/** Listar pedidos de un cliente con detalle del producto */
function obtenerPedidosPorCliente($cliente_id) {
    $conn       = getConexion();
    $cliente_id = (int)$cliente_id;
    $res        = $conn->query(
        "SELECT p.id, p.cantidad, p.total, p.fecha,
                pr.nombre AS producto_nombre, pr.precio AS producto_precio
         FROM pedidos p
         INNER JOIN productos pr ON p.producto_id = pr.id
         WHERE p.cliente_id = $cliente_id
         ORDER BY p.fecha DESC"
    );
    $data = [];
    while ($row = $res->fetch_assoc()) {
        $row['total']           = (float)$row['total'];
        $row['producto_precio'] = (float)$row['producto_precio'];
        $row['cantidad']        = (int)$row['cantidad'];
        $data[] = $row;
    }
    $conn->close();
    return $data;
}

/**
 * Crear nuevo pedido — un solo producto por pedido
 * Retorna: ['ok'=>bool, 'pedido_id'=>int, 'total'=>float, 'mensaje'=>string]
 */
function crearPedido($cliente_id, $producto_id, $cantidad) {
    // Validar cliente
    if (!obtenerClientePorId($cliente_id)) {
        return ['ok' => false, 'mensaje' => 'El cliente no existe'];
    }

    // Validar producto y obtener precio
    $producto = obtenerProductoPorId($producto_id);
    if (!$producto) {
        return ['ok' => false, 'mensaje' => 'El producto no existe'];
    }

    if ((int)$cantidad <= 0) {
        return ['ok' => false, 'mensaje' => 'La cantidad debe ser mayor a 0'];
    }

    $total = $producto['precio'] * (int)$cantidad;
    $conn  = getConexion();

    $sql = "INSERT INTO pedidos (cliente_id, producto_id, cantidad, total)
            VALUES ($cliente_id, $producto_id, $cantidad, $total)";

    if ($conn->query($sql)) {
        $id = $conn->insert_id;
        $conn->close();
        return ['ok' => true, 'pedido_id' => $id, 'total' => (float)$total, 'mensaje' => 'Pedido registrado correctamente'];
    }

    $err = $conn->error;
    $conn->close();
    return ['ok' => false, 'mensaje' => 'Error al guardar: ' . $err];
}
