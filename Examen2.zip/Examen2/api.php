<?php
// ============================================================
// api.php — Servicio REST del Sistema de Pedidos
// Requiere: crud.php (que a su vez requiere conexion.php)
//
// ENDPOINTS:
//   GET  api.php?recurso=productos
//   GET  api.php?recurso=clientes
//   GET  api.php?recurso=clientes&cedula=1801234567
//   GET  api.php?recurso=pedidos
//   GET  api.php?recurso=pedidos&cliente_id=1
//   POST api.php?recurso=pedidos   Body JSON: {cliente_id, producto_id, cantidad}
// ============================================================

require_once 'crud.php';

// ── CABECERAS ────────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ── ENRUTADOR ────────────────────────────────────────────────
$method  = $_SERVER['REQUEST_METHOD'];
$recurso = isset($_GET['recurso']) ? trim($_GET['recurso']) : '';

switch ($recurso) {

    // ── PRODUCTOS ────────────────────────────────────────────
    case 'productos':
        if ($method !== 'GET') { error(405, 'Método no permitido'); break; }

        $productos = obtenerProductos();
        echo json_encode(['success' => true, 'data' => $productos]);
        break;

    // ── CLIENTES ─────────────────────────────────────────────
    case 'clientes':
        if ($method !== 'GET') { error(405, 'Método no permitido'); break; }

        if (!empty($_GET['cedula'])) {
            // Buscar por cédula
            $cliente = obtenerClientePorCedula($_GET['cedula']);
            if ($cliente) {
                echo json_encode(['success' => true, 'data' => $cliente]);
            } else {
                error(404, 'Cliente no encontrado');
            }
        } else {
            // Listar todos
            $clientes = obtenerClientes();
            echo json_encode(['success' => true, 'data' => $clientes, 'total' => count($clientes)]);
        }
        break;

    // ── PEDIDOS ──────────────────────────────────────────────
    case 'pedidos':

        if ($method === 'GET') {

            if (!empty($_GET['cliente_id'])) {
                // Pedidos de un cliente
                $cliente = obtenerClientePorId((int)$_GET['cliente_id']);
                if (!$cliente) { error(404, 'Cliente no encontrado'); break; }

                $pedidos = obtenerPedidosPorCliente((int)$_GET['cliente_id']);
                echo json_encode([
                    'success'       => true,
                    'cliente'       => $cliente,
                    'pedidos'       => $pedidos,
                    'total_pedidos' => count($pedidos)
                ]);
            } else {
                // Todos los pedidos
                $pedidos = obtenerPedidos();
                echo json_encode(['success' => true, 'data' => $pedidos, 'total' => count($pedidos)]);
            }

        } elseif ($method === 'POST') {
            // Registrar nuevo pedido
            $input = json_decode(file_get_contents('php://input'), true);

            if (empty($input['cliente_id']) || empty($input['producto_id']) || empty($input['cantidad'])) {
                error(400, 'Faltan datos: cliente_id, producto_id y cantidad son requeridos');
                break;
            }

            $resultado = crearPedido(
                (int)$input['cliente_id'],
                (int)$input['producto_id'],
                (int)$input['cantidad']
            );

            if ($resultado['ok']) {
                http_response_code(201);
                echo json_encode([
                    'success'   => true,
                    'mensaje'   => $resultado['mensaje'],
                    'pedido_id' => $resultado['pedido_id'],
                    'total'     => $resultado['total']
                ]);
            } else {
                error(400, $resultado['mensaje']);
            }

        } else {
            error(405, 'Método no permitido');
        }
        break;

    // ── RECURSO INVÁLIDO ─────────────────────────────────────
    default:
        error(400, 'Recurso no válido. Opciones: productos, clientes, pedidos');
        break;
}

// ── FUNCIÓN AUXILIAR ─────────────────────────────────────────
function error($codigo, $mensaje) {
    http_response_code($codigo);
    echo json_encode(['success' => false, 'mensaje' => $mensaje]);
}
