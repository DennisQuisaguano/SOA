-- ============================================================
-- database.sql — Base de Datos: Sistema de Gestión de Pedidos
-- Ejecutar en phpMyAdmin o cliente MySQL antes de usar el sistema
-- ============================================================

CREATE DATABASE IF NOT EXISTS sistema_pedidos
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sistema_pedidos;

-- ── TABLA: productos (predefinidos/quemados) ─────────────────
CREATE TABLE IF NOT EXISTS productos (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(100)   NOT NULL,
    precio     DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    creado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── TABLA: clientes ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clientes (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    cedula     VARCHAR(20)   NOT NULL UNIQUE,
    nombre     VARCHAR(100)  NOT NULL,
    apellido   VARCHAR(100)  NOT NULL,
    telefono   VARCHAR(20),
    email      VARCHAR(150),
    creado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── TABLA: pedidos (un solo producto por pedido) ─────────────
CREATE TABLE IF NOT EXISTS pedidos (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id  INT           NOT NULL,
    producto_id INT           NOT NULL,
    cantidad    INT           NOT NULL DEFAULT 1,
    total       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    fecha       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id)  REFERENCES clientes(id)  ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE RESTRICT
);

-- ── DATOS: Productos predefinidos (jabón, shampoo, pasta dental)
INSERT INTO productos (nombre, precio) VALUES
('Jabón',        1.50),
('Shampoo',      3.25),
('Pasta Dental', 2.00);

-- ── DATOS: Clientes de ejemplo ───────────────────────────────
INSERT INTO clientes (cedula, nombre, apellido, telefono, email) VALUES
('1801234567', 'Juan',   'Pérez',     '0991234567', 'juan@email.com'),
('1809876543', 'María',  'González',  '0987654321', 'maria@email.com'),
('1805554433', 'Carlos', 'Rodríguez', '0993334455', 'carlos@email.com');

-- ── DATOS: Pedidos de ejemplo ────────────────────────────────
INSERT INTO pedidos (cliente_id, producto_id, cantidad, total) VALUES
(1, 1, 3,  4.50),
(1, 2, 1,  3.25),
(2, 3, 2,  4.00),
(3, 1, 5,  7.50);
