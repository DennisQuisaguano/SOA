<?php
// ============================================================
// conexion.php — Conexión a la Base de Datos
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');     // ← Cambia por tu usuario MySQL
define('DB_PASS', '');         // ← Cambia por tu contraseña MySQL
define('DB_NAME', 'sistema_pedidos');

function getConexion() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset("utf8mb4");

    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Error de conexión: ' . $conn->connect_error]);
        exit();
    }

    return $conn;
}
