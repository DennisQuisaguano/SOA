<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Producto;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductoController extends Controller
{


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "cliente_id"=> "required",
            "producto" => "required|in:jabon,shampo,pastaDentat",
            "cantidad" => "required",
        ]);

        if($validator->fails()){
            $data = [
                "message" => "Error al validar los datos",
                "status" => 401
            ];
            return response() -> json($data,401);
        }

        $cliente = Cliente::find($request->cliente_id);

        if(!$cliente){
            $data = [
                "message" => "El cliente no existe",
                "status" => 404
            ];
            return response() -> json($data,404);
        }

        if($request->producto == 'jabon')
            $total = ($request->cantidad * 0.3);
        if($request->producto == 'shampo')
            $total = ($request->cantidad * 0.4);
        if($request->producto == 'pastaDentat')
            $total = ($request->cantidad * 1);

        $pedido = Producto::create([
            "cliente_id" => $request->cliente_id,
            "producto" => $request->producto,
            "cantidad" => $request->cantidad,
            "total" => $total,
        ]);

       if(!$pedido){
            $data = [
                "message" => "Error al crear pedido",
                "status" => 401
            ];
            return response() -> json($data,401);
        }

        $data = [
            "message" => "Pedido realizado con exito ",
            "pedido" => $pedido,
            "status" => 201
        ];
        return response() -> json($data,201);
    }

}