<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use PhpParser\Node\Expr\FuncCall;

class Cliente extends Model
{
    protected $fillable = ["cedula","nombre","apellido"];

    public function productos(){
        return $this->hasMany(Producto::class);
    }
}
