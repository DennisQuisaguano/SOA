<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use PhpParser\Node\Expr\FuncCall;

class ClienteController extends Controller
{
    public function index()
    {
        $clientes = Cliente::all();
        return response()->json($clientes, 200);
    }
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "cedula" => "required|unique:clientes",
            "nombre" => "required",
            "apellido" => 'required',
        ]);

        if ($validator->fails()) {
            $data = [
                "message" => "Error al validar los datos",
                "errors" => $validator->errors(),
                "status" => 401,
            ];
            return response()->json($data, 401);
        }

        $clientes = Cliente::create([
            "cedula" => $request->cedula,
            "nombre" => $request->nombre,
            "apellido" => $request->apellido,
        ]);

        if (!$clientes) {
            $data = [
                "message" => "Error al crear al cliente",
                "status" => 401,
            ];
            return response()->json($data, 401);
        }

        $data = [
            "message" => "Cliente creado",
            "clientes" => $clientes,
            "status" => 201
        ];
        return response()->json($data, 201);
    }

    public function show($cedula)
    {
        $clientes = Cliente::where("cedula", $cedula)->first();

        if (!$clientes) {
            $data = [
                "message" => "Cliente no existente",
                "status" => 401,
            ];
            return response()->json($data, 401);
        }
        $data = [
            "clientes" => $clientes,
            "status" => 200
        ];
        return response()->json($data, 200);
    }

    public function historial($cedula)
    {
        $clientes = Cliente::where("cedula", $cedula)->first();

        if (!$clientes) {
            $data = [
                "message" => "El cliente no existe",
                "status" => 401
            ];
            return response()->json($data, 401);
        }

        $pedidos = Producto::where("cliente_id", $clientes->id)->get();
        if ($pedidos->isEmpty()) {
            $data = [
                "message" => "El cliente no tiene pedidos",
                "status" => 401
            ];
            return response()->json($data, 401);
        }
        $data = [
            "clientes" => $clientes,
            "pedidos" => $pedidos,
            "status" => 200,
        ];
        return response()->json($data, 200);
    }

}
