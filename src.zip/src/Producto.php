<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    protected $fillable = ["cliente_id","producto","cantidad","total"];

    public function clientes(){
        return $this->belongsTo(Cliente::class);
    }
}
