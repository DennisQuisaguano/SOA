<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestion de Clientes</title>
    <script src="js/jquery-4.0.0.min.js"></script>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>

<div class="contenedor">

    <h2>Gestion de Clientes y Pedidos</h2>

    <!-- BUSQUEDA -->
    <div class="card">
        <h5>Buscar cliente por cedula</h5>
        <div class="grupo-busqueda">
            <input type="text" id="buscarCedula" placeholder="Ingrese cedula...">
            <button class="btn-primario" onclick="buscarCedula()">Buscar</button>
            <button class="btn-secundario" onclick="cargarTodos()">Ver Todos</button>
        </div>
        <div id="mensajeCliente" class="mensaje-error"></div>
    </div>

    <!-- TABLA CLIENTES -->
    <div class="card">
        <h5>Clientes</h5>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="tablaClientes"></tbody>
        </table>
    </div>

    <!-- FORMULARIO NUEVO PEDIDO -->
    <div id="formularioPedidos" class="card" style="display:none;">
        <h5>Nuevo Pedido</h5>
        <label>Producto</label>
        <select id="producto">
            <option value="jabon">Jabon</option>
            <option value="shampo">Shampo</option>
            <option value="pastaDentat">Pasta Dental</option>
        </select>
        <label>Cantidad</label>
        <input type="number" id="cantidad" placeholder="Ej: 5" min="1">
        <div class="grupo-botones">
            <button class="btn-verde" onclick="guardarPedido()">Guardar</button>
            <button class="btn-rojo" onclick="$('#formularioPedidos').hide()">Cancelar</button>
        </div>
        <div id="mensajeProducto"></div>
    </div>

    <!-- HISTORIAL -->
    <div id="historial" class="card" style="display:none;">
        <h5>Historial de Pedidos</h5>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody id="tablaHistorial"></tbody>
        </table>
        <div id="mensaje"></div>
    </div>

</div>

<script>
    const ruta = "http://127.0.0.1:8000/api/cliente";
    const rutaPedidos = "http://127.0.0.1:8000/api/pedidos";
    let clienteSeleccionado;

    // Cargar todos los clientes
    function cargarTodos() {
        $("#mensajeCliente").html('');
        $.ajax({
            url: ruta,
            method: "get",
            success: function(data) {
                let filas = '';
                for (i = 0; i < data.length; i++) {
                    filas += `
                        <tr>
                            <td>${data[i].nombre}</td>
                            <td>${data[i].apellido}</td>
                            <td>
                                <button class="btn-azul" onclick="verHistorial('${data[i].cedula}')">Ver Historial</button>
                                <button class="btn-naranja" onclick="nuevoPedido('${data[i].id}')">Nuevo Pedido</button>
                            </td>
                        </tr>
                    `;
                }
                $("#tablaClientes").html(filas);
            },
            error: function(error) {
                $("#mensajeCliente").html("Error al cargar clientes");
            }
        });
    }

    // Ver historial
    function verHistorial(cedula) {
        $("#historial").show();
        $.ajax({
            url: ruta + "/" + cedula + "/historial",
            method: "get",
            success: function(data) {
                let filas = '';
                for (i = 0; i < data.pedidos.length; i++) {
                    filas += `
                        <tr>
                            <td>${data.pedidos[i].producto}</td>
                            <td>${data.pedidos[i].cantidad}</td>
                            <td>$${data.pedidos[i].total}</td>
                        </tr>
                    `;
                }
                $("#tablaHistorial").html(filas);
                $("#mensaje").html('');
            },
            error: function(error) {
                $("#tablaHistorial").html('');
                $("#mensaje").attr("class", "mensaje-error").html(error.responseJSON.message);
            }
        });
    }

    // Mostrar formulario
    function nuevoPedido(id) {
        clienteSeleccionado = id;
        $("#formularioPedidos").show();
        $("#mensajeProducto").html('');
    }

    // Guardar pedido
    function guardarPedido() {
        $.ajax({
            url: rutaPedidos,
            method: "post",
            data: {
                cliente_id: clienteSeleccionado,
                producto: $("#producto").val(),
                cantidad: $("#cantidad").val(),
            },
            success: function(data) {
                $("#mensajeProducto").attr("class", "mensaje-exito").html(
                    data.message +
                    " | Producto: " + data.pedido.producto +
                    " | Cantidad: " + data.pedido.cantidad +
                    " | Total: $" + data.pedido.total
                );
            },
            error: function(error) {
                $("#mensajeProducto").attr("class", "mensaje-error").html(error.responseJSON.message);
            }
        });
    }

    // Buscar por cedula
    function buscarCedula() {
        let cedula = $("#buscarCedula").val();
        $.ajax({
            url: ruta + "/" + cedula,
            method: "get",
            success: function(data) {
                let filas = `
                    <tr>
                        <td>${data.clientes.nombre}</td>
                        <td>${data.clientes.apellido}</td>
                        <td>
                            <button class="btn-azul" onclick="verHistorial('${data.clientes.cedula}')">Ver Historial</button>
                            <button class="btn-naranja" onclick="nuevoPedido('${data.clientes.id}')">Nuevo Pedido</button>
                        </td>
                    </tr>
                `;
                $("#tablaClientes").html(filas);
                $("#mensajeCliente").html('');
            },
            error: function(error) {
                $("#tablaClientes").html('');
                $("#mensajeCliente").html(error.responseJSON.message).show().delay(3000).fadeOut();
            }
        });
    }

    cargarTodos();
</script>

</body>
</html>