<?php

include_once("Crud.php");

$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo) {
    case "GET":
        if (isset($_GET['cedula'])) {
            Cruds::buscar();
        } else {
            Cruds::selectEst();
        }
        break;
    case "POST":
        Cruds::insertEst();
        break;
    case "PUT":
        Cruds::ventas();
        break;
    case "DELETE":
        Cruds::deleteEst();
        break;
}
?>
