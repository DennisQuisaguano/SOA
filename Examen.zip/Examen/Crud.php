<?php

include_once("conexion.php");

class Cruds
{

    public static function selectEst()
    {
        $conectar = Conexion::conectar();
        $sqlSelect = "SELECT * FROM productos";
        $resultado = $conectar->prepare($sqlSelect);
        $resultado->execute();
        $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($data);
    }


    public static function insertEst()
    {
        $conectar = Conexion::conectar();
        $nombre = $_POST['txtNombre'] ?? '';
        $precio = $_POST['txtPrecio'] ?? '';
        $cantidad = $_POST['txtCantidad'] ?? '';

        if (empty($nombre) || empty($precio) || empty($cantidad)) {
            $data = array('error' => 'Todos los campos son obligatorios.');
            echo json_encode($data);
            return;
        }

        try {
            $sqlInsert = "INSERT INTO productos (nombre, precio, cantidad) VALUES (?, ?, ?)";
            $resultado = $conectar->prepare($sqlInsert);

            if ($resultado->execute(array($nombre, (float)$precio, (int)$cantidad))) {
                $data = array('success' => 'Producto insertado correctamente');
                echo json_encode($data);
            } else {
                $error = $resultado->errorInfo();
                $data = array('error' => 'Error en la BD: ' . $error[2]);
                echo json_encode($data);
            }
        } catch (Exception $e) {
            $data = array('error' => 'Excepción: ' . $e->getMessage());
            echo json_encode($data);
        }
    }


    public static function deleteEst()
    {
        $conectar = Conexion::conectar();
        $id = $_GET['txtId'] ?? '';

        if (empty($id)) {
            $data = array('error' => 'ID requerido');
            echo json_encode($data);
            return;
        }

        try {
            $sqlDelete = "DELETE FROM productos WHERE id=?";
            $resultado = $conectar->prepare($sqlDelete);
            $resultado->execute([$id]);
            $data = array('success' => 'Producto eliminado correctamente');
            echo json_encode($data);
        } catch (Exception $e) {
            $data = array('error' => 'Error: ' . $e->getMessage());
            echo json_encode($data);
        }
    }

    public static function ventas()
    {
        try {
            $conectar = Conexion::conectar();
            $id = $_GET['txtId'] ?? '';
            $precio = $_GET['txtPrecio'] ?? '';
            $cantidad = (int) ($_GET['txtCantidad'] ?? 0);

            if (empty($id) || $cantidad <= 0) {
                $data = array('error' => 'ID y cantidad son requeridos');
                echo json_encode($data);
                return;
            }

            $sqlCantidadyPrecio = "SELECT precio, cantidad FROM productos WHERE id=?";
            $resultado = $conectar->prepare($sqlCantidadyPrecio);
            $resultado->execute([$id]);
            $data = $resultado->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                $response = array('error' => 'Producto no encontrado');
                echo json_encode($response);
                return;
            }

            $precioSql   = (float) $data['precio'];
            $cantidadSql = (int)   $data['cantidad'];

            if ($cantidad > $cantidadSql) {
                $data = array('error' => 'La cantidad ingresada está fuera del rango. Stock disponible: ' . $cantidadSql);
                echo json_encode($data);
            } else {
                $total = $precioSql * $cantidad;
                $nuevaCantidad = $cantidadSql - $cantidad;
                $sqlUpdate = "UPDATE productos SET cantidad=? WHERE id=?";
                $resultado = $conectar->prepare($sqlUpdate);
                if ($resultado->execute([$nuevaCantidad, $id])) {
                    $data = array('success' => 'Venta realizada. Total a pagar: $' . number_format($total, 2));
                    echo json_encode($data);
                } else {
                    $data = array('error' => 'Error al actualizar el stock');
                    echo json_encode($data);
                }
            }
        } catch (Exception $e) {
            $data = array('error' => 'Excepción: ' . $e->getMessage());
            echo json_encode($data);
        }
    }


    public static function buscar()
    {
        $conectar = Conexion::conectar();
        $nombre = $_GET['nombre'] ?? '';

        if (empty($nombre)) {
            $data = array('error' => 'Nombre de producto requerido');
            echo json_encode($data);
            return;
        }

        try {
            $sqlBuscar = "SELECT * FROM productos WHERE nombre LIKE ?";
            $resultado = $conectar->prepare($sqlBuscar);
            $nombre_busqueda = '%' . $nombre . '%';

            if ($resultado->execute(array($nombre_busqueda))) {
                $data = $resultado->fetchAll(PDO::FETCH_ASSOC);
                if (count($data) > 0) {
                    echo json_encode($data);
                } else {
                    echo json_encode(array('error' => 'Producto no encontrado'));
                }
            } else {
                $error = $resultado->errorInfo();
                $data = array('error' => 'Error ' . $error[2]);
                echo json_encode($data);
            }
        } catch (Exception $e) {
            $data = array('error' => 'Excepción: ' . $e->getMessage());
            echo json_encode($data);
        }
    }
}