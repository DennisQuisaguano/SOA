<?php

class Conexion
{
    public static function conectar()
    {
        $server = "localhost";
        $user = "root";
        $password = "";
        $database = "productos";

        try {
            $conn = new PDO("mysql:host=$server;dbname=$database;charset=utf8", $user, $password);
            // Configurar PDO para mostrar errores
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            die(json_encode(array("error" => "Conexión fallida: " . $e->getMessage())));
        }
    }
}
?>
